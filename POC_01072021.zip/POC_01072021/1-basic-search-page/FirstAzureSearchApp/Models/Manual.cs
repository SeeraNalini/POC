﻿using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Indexes.Models;
using Microsoft.Spatial;
using System;
using System.Text.Json.Serialization;

namespace FirstAzureSearchApp.Models
{
 
    // public class Rootobject
    //{
    //    public string odatacontext { get; set; }
    //    public SearchResult[] SearchResult { get; set; }
    //}

    public class Manual
    {
        public float searchscore { get; set; }
        public string metadata_storage_content_type { get; set; }
        public int metadata_storage_size { get; set; }
        public DateTime metadata_storage_last_modified { get; set; }
        public string metadata_storage_path { get; set; }
        public string merged_content { get; set; }
        public string metadata_content_type { get; set; }
        //public string metadata_title { get; set; }
        public string[] text { get; set; }
        public string[] layoutText { get; set; }
        //public string[] merged_text { get; set; }
    }
//    public enum ModelNumber
//    {
//"8FGCU15-S20",
//"8FGCU20-32",
//"8FG(D)U15-32",
//"8FGCU20-32",
//"8FG(D)U15-32",
//"8FGC35-70U",
//"8FG(D)35-80U"
//    }
}
