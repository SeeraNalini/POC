﻿using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using FirstAzureSearchApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Text;
using System.Linq;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Azure.Storage.Auth;
//using CloudStorageAccount = Microsoft.WindowsAzure.Storage.CloudStorageAccount;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System.Web;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;
using System.Net;
using BlobContainerPermissions = Microsoft.Azure.Storage.Blob.BlobContainerPermissions;
using BlobContainerPublicAccessType = Microsoft.Azure.Storage.Blob.BlobContainerPublicAccessType;
using Azure.Storage.Blobs.Specialized;
using Azure.Search.Documents.Models;
using Azure.Search.Documents.Indexes.Models;

namespace FirstAzureSearchApp.Controllers
{

    public class HomeController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        public string SearchModelNum = string.Empty;
        public HomeController(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult submit(FormCollection formcollection)
        {
            SearchModelNum = formcollection["modelNumTxt"];
          
            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<ActionResult> Index(SearchData model)
        {
            try
            {
                // Ensure the search string is valid.
                if (model.searchText == null)
                {
                    model.searchText = "";
                }

                // Make the Azure Cognitive Search call.
                await RunQueryAsync(model).ConfigureAwait(false);
            }
            catch
            {
                return View("Error", new ErrorViewModel { RequestId = "1" });
            }

            return View(model);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private static SearchClient _searchClient;
        private static SearchIndexClient _indexClient;
        private static IConfigurationBuilder _builder;
        private static IConfigurationRoot _configuration;

      
        private async void InitSearch()
        {
            // Create a configuration using the appsettings file.
            _builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            _configuration = _builder.Build();

            // Pull the values from the appsettings.json file.
            string searchServiceUri = _configuration["SearchServiceUri"];
            string queryApiKey = _configuration["SearchServiceQueryApiKey"];

            // Create a service and index client.
            _indexClient = new SearchIndexClient(new Uri(searchServiceUri), new AzureKeyCredential(queryApiKey));
             _searchClient = _indexClient.GetSearchClient("azureblob-index1");
            // DownloadFile();
            //await DownloadFileAsync();
            

        }


        private async Task<ActionResult> RunQueryAsync(SearchData model)
        {
            try
            {
                InitSearch();
                string path = string.Empty;
                string filename = string.Empty;
                var options = new SearchOptions()
                {
                    IncludeTotalCount = true

                };

                string searchPhrase = model.searchText + "&" + model.modelNumber;
                // Enter Hotel property names into this list so only these values will be returned.
                // If Select is empty, all values will be returned, which can be inefficient.
                //options.Select.Add("HotelName");
                //options.Select.Add("Description");
                options.SearchMode = SearchMode.All;
                options.QueryType = SearchQueryType.Full;
                options.HighlightFields.Add("text");
                // options.ScoringProfile = ScoringProfile.Equals;
                options.Select.Add("metadata_storage_content_type");
                options.Select.Add("metadata_storage_size");
                options.Select.Add("metadata_storage_last_modified");
                options.Select.Add("metadata_storage_path");
                options.Select.Add("merged_content");
                options.Select.Add("metadata_title");
                options.Select.Add("text");
                options.Select.Add("layoutText");
                options.Select.Add("merged_text");
                // For efficiency, the search call should be asynchronous, so use SearchAsync rather than Search.
                model.resultList = await _searchClient.SearchAsync<Manual>(searchPhrase, options).ConfigureAwait(false);

                string path1 = "aHR0cHM6Ly90bWhibG9iLmJsb2IuY29yZS53aW5kb3dzLm5ldC90bWhibG9iY29udGFpbmVyL2Jsb2Jmb2xkZXIvU2FtcGxlX21hbnVhbDEucGRm0";
                // string path2 = "aHR0cHM6Ly90bWhibG9iLmJsb2IuY29yZS53aW5kb3dzLm5ldC90bWhibG9iY29udGFpbmVyL2Jsb2Jmb2xkZXIvNFklMjBFbmdpbmUlMjBXaXJpbmclMjBEaWFncmFtLnBkZg2";

               // var s = model.resultList.GetResults().ToList();
              
                foreach (var m in model.resultList.GetResults().ToList())
                {
                  
                    var textHighlight = m.Highlights.Values.ToList();

                    //for (var i = 0; i < textHighlight.Count; i++)
                    //{
                    //    if (textHighlight[i].Contains("<em>"))
                    //    {
                    //        textHighlight[i].ToString().Replace($"<font style="+"background:"+"yellow;"+">");

                    //    }

                    //    if (textHighlight[i].Contains("</em>"))
                    //    {
                    //        textHighlight[i].ToString().Replace("</font>");

                    //    }

                    //}





                    if (!(path1 == m.Document.metadata_storage_path))
                    {

                        path = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(m.Document.metadata_storage_path));
                            // Uri baseUri = new Uri(path);
                            m.Document.metadata_storage_path = GetFileNameFromUrl(path);

                    }
                }
              
                //string path1 = "aHR0cHM6Ly90bWhibG9iLmJsb2IuY29yZS53aW5kb3dzLm5ldC90bWhibG9iY29udGFpbmVyL2Jsb2Jmb2xkZXIvU2FtcGxlX21hbnVhbDEucGRm0";
                //string path2 = "aHR0cHM6Ly90bWhibG9iLmJsb2IuY29yZS53aW5kb3dzLm5ldC90bWhibG9iY29udGFpbmVyL2Jsb2Jmb2xkZXIvNFklMjBFbmdpbmUlMjBXaXJpbmclMjBEaWFncmFtLnBkZg2";


                //foreach (var m in model.resultList.GetResults().ToList())
                //{
                //    if (!(path1 == m.Document.metadata_storage_path))
                //    {
                //        if (!(path2 == m.Document.metadata_storage_path))
                //        {
                //            path = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(m.Document.metadata_storage_path));
                //            // Uri baseUri = new Uri(path);
                //            m.Document.metadata_storage_path = GetFileNameFromUrl(path);
                //        }
                //    }
                //}
                // Display the results.
                return View("Index", model);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);

            }

        }
        public async Task DownloadFileAsync()
        {

            BlobServiceClient blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=tmhblob;AccountKey=7Z9uTrxuFUcSDrQykxptkLJdIb1zogKAQfKpmT7Cire5qA+NJkgbUyXLFTs/uhozpOlBIfp0FU34x31wkUHqYA==;EndpointSuffix=core.windows.net");
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient("tmhblobcontainer");
            BlobClient blobClient = containerClient.GetBlobClient("4Y_Engine_Wiring_Diagram.pdf");
            //Microsoft.Azure.Storage.Blob.CloudBlobContainer blobContainer = containerClient.GetContainerReference(containerName);
            //Microsoft.Azure.Storage.Blob.CloudBlockBlob blob = containerClient.GetBlockBlobReference(targetFileName);
            //blob.FetchAttributes();
            //long fileByteLength = blob.Properties.Length;
            //Byte[] myByteArray = new Byte[fileByteLength];
            //blob.DownloadToByteArray(myByteArray, 0);

            //long fileByteLength = blob.Properties.Length;
            //byte[] fileContent = new byte[fileByteLength];
            //for (int i = 0; i < fileByteLength; i++)
            //{
            //    fileContent[i] = 0x20;
            //}
            //blob.DownloadToByteArrayAsync(fileContent, 0);


            //    return new EmptyResult();



            //return new EmptyResult();
        }
        //public FileResult GetPdf()
        //{
        //    string ReportURL = "https://tmhblob.blob.core.windows.net/tmhblobcontainer/blobfolder/4Y_Engine_Wiring_Diagram.pdf";
        //    //string ReportURL = @"G:/4Y_Engine_Wiring_Diagram.pdf";
        //    byte[] FileBytes = System.IO.File.ReadAllBytes(ReportURL);
        //    return File(FileBytes, "application/pdf");

        //}
        //public ActionResult ShowPdf()
        //{
        //    string fileName = "4Y_Engine_Wiring_Diagram.pdf";

        //    var storageAccount = CloudStorageAccount.Parse(_configuration["StorageConnectionString"]);
        //    var blobClient = storageAccount.CreateCloudBlobClient();
        //    var container = blobClient.GetContainerReference("tmhblobcontainer");
        //    var blockBlob = container.GetBlockBlobReference(fileName);
        //    blockBlob.FetchAttributes();

        //    //long fileByteLength = blockBlob.Properties.Length;
        //    //byte[] fileContent = new byte[fileByteLength];
        //    //for (int i = 0; i < fileByteLength; i++)
        //    //{
        //    //    fileContent[i] = 0x20;
        //    //}

        //    var ms = new MemoryStream();

        //    blockBlob.DownloadToStreamAsync(ms);

        //    return new FileContentResult(ms.ToArray(), blockBlob.Properties.ContentType);
        //    //blockBlob.DownloadToByteArray(fileContent, 0);



        //    //return new EmptyResult();
        //    //Response.Headers.Append("Content-Disposition", "inline; filename=" + fileName);
        //    //return File(blockBlob.(), "application/pdf");
        //}
        public ActionResult GetBlobItems(string filename)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + filename;
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["StorageConnectionString"]);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient("tmhblobcontainer");
            BlobClient blobClient = containerClient.GetBlobClient(filename);
            //await containerClient.SetAccessPolicyAsync(new BlobContainerPermissions {PublicAccess=BlobContainerPublicAccessType.Blob});
            List<Uri> blobsItems = new List<Uri>();
            foreach (BlobItem blobItem in containerClient.GetBlobs())
            {
                //deleted blobItem /file status can be retrived by  blobItem.deleted
                if (containerClient.GetBlockBlobClient(blobItem.Name).Uri.ToString().Contains(filename))
                {
                    blobsItems.Add(containerClient.GetBlockBlobClient(blobItem.Name).Uri);
                }

            }
            
            Response.Redirect(blobsItems.First().ToString());
            return new EmptyResult();
        }
        public ActionResult GetPDF1(string filename)
        {

            // string downloadFilePath = @"C:\Users\";
            //string path = path = downloadFilePath + "\\" + filename;
            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + filename;
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["StorageConnectionString"]);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient("tmhblobcontainer");
            BlobClient blobClient = containerClient.GetBlobClient(filename);
            //await containerClient.SetAccessPolicyAsync(new BlobContainerPermissions {PublicAccess=BlobContainerPublicAccessType.Blob});
            List<Uri> blobsItems = new List<Uri>();
            foreach (BlobItem blobItem in containerClient.GetBlobs())
            {
                blobsItems.Add(containerClient.GetBlockBlobClient(blobItem.Name).Uri);
              
            }

            //if (blobClient.Exists())
            //{// Get a reference to a blob

            // // Download the blob's contents and save it to a file
            //    BlobDownloadInfo download = await blobClient.DownloadAsync();
            //    //path = downloadFilePath + "\\" + filename;

            //    using (FileStream downloadFileStream = System.IO.File.OpenWrite(path))
            //    {
            //        await download.Content.CopyToAsync(downloadFileStream);
            //        downloadFileStream.Close();
            //    }
            //}

            //WebClient client = new WebClient();
            //Byte[] buffer = client.DownloadData(path);
            //var ext = Path.GetExtension(path).ToLowerInvariant();
            //if (buffer != null)
            //{
            //    Response.ContentType = GetMimeTypes()[ext];
            //    Response.Headers.Add("content-length", buffer.Length.ToString());
            //    await Response.Body.WriteAsync(buffer);
            //}


            return new EmptyResult();

        }
        private Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
        {
            {".txt", "text/plain"},
            {".pdf", "application/pdf"},
            {".doc", "application/vnd.ms-word"},
            {".docx", "application/vnd.ms-word"},
            {".png", "image/png"},
            {".jpg", "image/jpeg"}
           
        };
        }
        static string GetFileNameFromUrl(string url)
        {
            Uri uri;
            if (!Uri.TryCreate(url, UriKind.Absolute, out uri))
                uri = new Uri(url);

            return Path.GetFileName(uri.LocalPath);
        }

    }
}