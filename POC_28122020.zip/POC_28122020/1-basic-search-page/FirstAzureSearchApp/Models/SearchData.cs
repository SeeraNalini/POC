﻿using Azure.Search.Documents.Models;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FirstAzureSearchApp.Models
{
    public class SearchData
    {
        // The text to search for.
        [Required(AllowEmptyStrings = false)]
        
        public string searchText { get; set; }
        public string prodDate { get; set; }
        public string modelNumber { get; set; }

        // The list of results.
        //public SearchResults<Hotel> resultList;
        public SearchResults<Manual> resultList;
    }
}
